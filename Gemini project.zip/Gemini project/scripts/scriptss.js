var w = window.outerWidth;
var h = window.innerHeight;

document.getElementById("bk_pic").width = w;

alert(w)